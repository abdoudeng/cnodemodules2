module.exports = require('./register')().implementation
