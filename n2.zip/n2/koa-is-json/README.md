# Koa Is JSON

Check if a body is JSON
