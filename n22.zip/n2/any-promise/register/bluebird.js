'use strict';
require('../register')('bluebird', {Promise: require('bluebird')})
