# Inflate

This module implements a simple interface that when given deflated data returns the inflated version.

## inflate(deflated) -> inflated

```js
var inflate = require('js-git/lib/inflate');

var inflated = inflate(deflated);
```
