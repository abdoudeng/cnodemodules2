
1.8.0 / 2018-01-12
==================

**features**
  * [[`f89c675`](http://github.com/koajs/locales/commit/f89c6755c1b16a78617ceb071d1c9a8137c8c7a6)] - feat: add writeCookie option (#28) (Tao Xu <<angelxutao@gmail.com>>)

1.7.0 / 2017-04-27
==================

  * feat: Add more debug information on a 'silly' level

1.6.0 / 2017-04-27
==================

  * feat: support header lang from localeAlias (#27)

1.5.2 / 2017-01-13
==================

  * fix: make sure signed=false on set/get cookie (#24)

1.5.1 / 2016-05-21
==================

  * deps: humanize-ms@1.2.0, use ^ (#22)

1.5.0 / 2016-03-16
==================

  * feat: add localeAlias options
  * chore(package): update benchmark to version 2.0.0

1.4.4 / 2015-12-23
==================

  * fix: return empty if the key-value is empty value

1.4.3 / 2015-12-09
==================

 * fix: if header sent, don't set the cookie
 * doc(options.dirs): fix api doc

1.4.2 / 2015-09-20
==================

 * refact(es6): use es6 syntax.

1.4.1 / 2015-09-18
==================

 * refact(nested-data): transform nested data on load localization data.

1.4.0 / 2015-09-17
==================

 * feat: Support nested locale keys.

1.3.1 / 2015-09-15
==================

 * fix: merge-descriptors should be in dependencies

1.3.0 / 2015-09-14
==================

 * feat: Multiple locale paths support.
 * refact(apply): apply is not too slow than direct call. fixed #2

1.2.0 / 2015-08-31
==================

 * refact(endsWith): endsWith is fast than regexp
 * revert slice arguments to args

1.1.0 / 2015-08-31
==================

 * feat: paramter support object
 * refact: arguments to array.
 * optimize use regexp without caught group

1.0.2 / 2015-05-17
==================

 * feat: support *.properties resource files

1.0.1 / 2015-05-16
==================

 * Optimization killers

1.0.0 / 2015-05-16
==================

 * first release
