# Sponsored Development

As a company, you can sponsor development of specific features to the js-git ecosystem.

## In Progress Sponsored Features

 - JS-Git - Encrypted Filesystem - Anonymous
 - Tedit - Web Runtime - Anonymous

## Completed Sponsored Features

 - Tedit - Live Export to VFS - Anonymous
