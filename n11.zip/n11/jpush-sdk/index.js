/**
 * @author: JPush
 * @Date: 17-02-01
 * @version: 3.3.2
 */
module.exports = require('./lib/JPush/JPush.js')
