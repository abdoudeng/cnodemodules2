describe("less.js Visitor Plugin", function() {
    testLessEqualsInDocument();
});
