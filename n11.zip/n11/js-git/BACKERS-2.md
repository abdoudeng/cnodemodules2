# BountySource Backers

After the successful KickStarter, I decided to do a second fundraiser so that I could continue working on js-git.  This was done as a [bountysource fundraiser][].  These are the people that contributed there. (Many were repeat contributers)

## Innovation Enabler

> At this level of support, you are truly enabling open development.  I assume you are backing on behalf of a company who can use js-git.  I'll send you a small pack of stickers and a few t-shirts.
>
>Also, for being so awesome, I can fly out to visit your team to discuss how to integrate js-git once it's usable (US only unless you help cover costs).

 - Mozilla <https://www.mozilla.org>

## Heavy Backer

> For committing to back a substantial amount of the project, I'll send you stickers, tshirts.
>
> Also I'll list you in BACKERS-2.md with your name, url, and short blurb.

 - Adobe <http://www.adobe.com/>

## Supporter

> For backing this project we'll send you a js-git laptop sticker so you can show your support to the world.
>
>Also you will be listed in BACKERS-2.md for all history to see.

 - jden
 - othiym23
 - chrisjpowers
 - JohnSz
 - sindresorhus
 - aeby
 - maks
 - julien51
 - mofoghlu
 - JPBarringer
 - jeffslofish

## Basic Supporter

> Your name will be listed in BACKERS-2.md in the main source tree of js-git.

 - servergrove
 - bluntworks
 - pdillon
 - pizzapanther
 - nschneble
 - Ohad Assulin
 - oxy
 - lettertwo
 - tmcw
 - joeandaverde
 - airportyh
 - nathanathan
 - signalwerk
 - ripta
 - vaughan
 - neilk
 - mikehenrty
 - vardump
 - Peter Burns
 - blittle
 - Stefan Stoichev
 - amaxwell01
 - dannyfritz
 - George V. Reilly
 - euforic
 - gflarity
 - generalhenry
 - piredman
 - Rebecca
 - st-luke
 - asafy
 - alessioalex
 - sergi
 - diversario
 - seriema
 - desaintmartin
 - DinisCruz
 - gotcha
 - nikolay
 - saintedlama
 - begebot
 - jbarratt
 - mikaelkaron
 - colinscroggins
 - Eric Elliott
 - owenb
 - balupton
 - fjakobs
 - romainhuet
 - angelyordanov
 - cscott
 - ilsken

## Anonymous Supporters

There were also 33 other people who didn't claim any level of reward but contributed to the fundraiser.  Some as much as $500 from individuals.  Thank you all for the support.

[bountysource fundraiser]: https://www.bountysource.com/fundraisers/325-js-git
